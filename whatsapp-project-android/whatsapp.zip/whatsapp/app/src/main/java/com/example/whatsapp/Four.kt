package com.example.whatsapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Four : AppCompatActivity() {
    lateinit var chat_name1:Button
    lateinit var chat_name4:Button
    lateinit var toolbar: Toolbar



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_four)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets

        }
        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        chat_name1=findViewById(R.id.chat_name1)
        chat_name4=findViewById(R.id.chat_name4)



    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        // Inflate menu with ic_more_vert icon
        menuInflater.inflate(R.menu.manu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_more -> {
                // Anchor popup to the toolbar
                showPopupMenu(toolbar)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showPopupMenu(anchor: View) {
        val popup = PopupMenu(this, anchor, Gravity.END)
        popup.menuInflater.inflate(R.menu.more_menu, popup.menu)

        popup.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.action_logout1 -> {
                    Toast.makeText(this, "New Group clicked", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.action_logout2 -> {
                    Toast.makeText(this, "New Broadcast clicked", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.action_logout3 -> {
                    Toast.makeText(this, "Linked Devices clicked", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.action_logout4 -> {
                    Toast.makeText(this, "Payments clicked", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.action_logout -> {
                    Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                    true
                }
                else -> false
            }
        }

        popup.show()
    }

    override fun onStart() {
        super.onStart()
        chat_name1.setOnClickListener {
            val chat_name1=Intent(Intent.ACTION_VIEW)
            chat_name1.data=Uri.parse("https://wa.me/+919974385253?=Hello how are you ?")
            startActivity(chat_name1)
        }
        chat_name4.setOnClickListener {
            val chat_name4=Intent(Intent.ACTION_VIEW)
            chat_name4.data=Uri.parse("https://wa.me/+919974385253?=Hello how are you ?")
            startActivity(chat_name4)
        }


    }
}